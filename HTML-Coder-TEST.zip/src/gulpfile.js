const gulp = require('gulp'); // Подключение gulp
const postcss = require('gulp-postcss'); // Подключение PostCSS
const concatcss = require('gulp-concat-css');// Объединение всех css файлов в один файл
const sourcemaps = require('gulp-sourcemaps');// Подключение Sourcemaps https://www.npmjs.com/package/gulp-sourcemaps
const autoprefixer = require('autoprefixer');// Подключение Autoprefixer https://github.com/postcss/autoprefixer
const cssnext = require('cssnext');// Подключение postcss-cssnext http://cssnext.io/
const cssnano = require('cssnano');// Подключение минификатора http://cssnano.co/
const sass = require('gulp-sass');// Подключение SCSS плагина для компилирования файлов

const stylesheetsSources = './css/style.css';
const cssDestination = './../dist/css';


/**
 * Описание задачи, которая будет переносить CSS из src в dist и при этом добавлять браузерные префиксы и мапы
 * @returns {*}
 */
let publishCssAndAddBrowserPrefixes = () => {
    let processors = [
        autoprefixer({
            remove: false, // отключение автоудаления префиксов из исходного кода
            browsers: ['last 3 versions'], // поддержка браузера
        }),
        cssnext,
        cssnano({
            discardUnused: {
                fontFace: false // отключение автоудаления не используемых font-face
            }
        }),
    ];
    return gulp.src(stylesheetsSources)
    .pipe(sourcemaps.init())
    .pipe(sass().on('error', sass.logError))
    .pipe(postcss(processors))
    .pipe(sourcemaps.write('.'))
    .pipe(gulp.dest(cssDestination))
};

/*  Перенос всех .js файлов в dist */

const jsSources = './js/*';
const jsDestination = './../dist/js';

let CopyJsFromSource = () => {
    return gulp.src(jsSources)
        .pipe(gulp.dest(jsDestination))
};

gulp.task ('publish-js', () => {
    CopyJsFromSource()
});
/**
 * Регистрация вышеописанной задачи в gulp 
 */
gulp.task('publish-css', () => {
    return publishCssAndAddBrowserPrefixes()
});

/**
 * Регистрация filewatcher, который будет запускать publishCssAndAddBrowserPrefixes задачу при изменении css файлов
 */
gulp.task('watch', () => {
    return gulp.watch([stylesheetsSources], publishCssAndAddBrowserPrefixes)
});

/**
 * Добавление filewatcher, который будет запускать publishCssAndAddBrowserPrefixes задачу при изменении css файлов
 */
gulp.task('default', ['watch']);

/*    Copy files from node_modules    */

const jQuerySources = './node_modules/jquery/dist/jquery.min.js';
const jQueryDestination = './js';

const scrollSources = './node_modules/perfect-scrollbar/dist/perfect-scrollbar.js';
const scrollDestination = './js';

const scrollStylesheetSources = './node_modules/perfect-scrollbar/css/perfect-scrollbar.css';
const scrollStylesheetDestination = './css';

let CopyJqueryFromNodeModules = () => {
    return gulp.src(jQuerySources)
     .pipe(gulp.dest(jQueryDestination))
};

gulp.task ('copy-jquery', () => {
    CopyJqueryFromNodeModules()
});

let CopyScrollFromNodeModules = () => {
    return gulp.src(scrollSources)
     .pipe(gulp.dest(scrollDestination))
};

gulp.task ('copy-scroll', () => {
    CopyScrollFromNodeModules()
});

let CopyScrollStylesheetsFromNodeModules = () => {
    return gulp.src(scrollStylesheetSources)
        .pipe(gulp.dest(scrollStylesheetDestination))
};

gulp.task ('copy-scroll-styles', () => {
    CopyScrollStylesheetsFromNodeModules()
});

/*  Объединение всех css файлов в один  */

const styleBundle ='./css/0style.css';

let uniteCssInOne = () => {
    return gulp.src(styleBundle)
        .pipe(concatcss("style.css"))
        .pipe(gulp.dest('./css/'));
};

gulp.task ('unite-css', () => {
    return uniteCssInOne()
});